package com.my.dbprocessor;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface StatementCreater
{
	/**
	 * 按照数组中的顺序将值一次写入数据表，产生一个statement
	 * @param tableName 表名字
	 * @param values 要被写入数据的一条记录的object数组
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createInsertStatement(String tableName ,Object... values) throws SQLException;
	
	/**
	 * 删除数据表中的一条数据 大概就是where cloName = value;
	 * @param tableName 表名
	 * @param colName 列名
	 * @param value 匹配的值
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createDeleteStatement(String tableName , String colName , Object value) throws SQLException;
	
	/**
	 * 删除数据表中的一条数据 大概就是where cloName[0] = value[0] AND cloName[1] = value[1] AND ...;
	 * @param tableName 表名
	 * @param colName 列名数组
	 * @param value 匹配的值的数组
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createDeleteStatement(String tableName , String[] colName , Object[] value) throws SQLException;

	/**
	 * 更新表中的一条数据  大概就是  set colName[0] = object[0] , colName[1] = object[1] where whichCol = whichValue
	 * @param tableName 表名
	 * @param whichCol 用于定位一条记录的字段
	 * @param whichValue 用于定位一条记录的字段的值
	 * @param colName 列名数组
	 * @param values 匹配的值的数组
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createUpdateStatement(String tableName , String[] whichCols , Object[] whichValue , 
			String[] colName , Object[] values) throws SQLException;
	
	/**
	 * 更新表中的一条数据  大概就是  set colName = object , colName = object where whichCol = whichValue
	 * @param tableName 表名
	 * @param whichCol 用于定位一条记录的字段
	 * @param whichValue 用于定位一条记录的字段的值
	 * @param colName 列名
	 * @param values 匹配的值
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createUpdateStatement(String tableName , String whichCol , Object whichValue , 
			String colName , Object value) throws SQLException;
	
	/**
	 * 查询整张表
	 * @param tbaleName 表名
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createGetAllItemsStatement(String tbaleName) throws SQLException;
	
	/**
	 * 查询整张表并且排序
	 * @param table 表名
	 * @param whichColSort 要根据那一列排序
	 * @param sortWay 排序方式 升序还是降序 升序传ASCE 降序传DESC
	 * @return 可被执行的statement
	 */
	public abstract PreparedStatement createGetAllItemsStatement(String table , String whichCol , String sortWay) throws SQLException;

	/**
	 * 通过具体的值来查找 例如 select * from tableName where whichCol = whatValue;
	 * @param tableName 表名
	 * @param whichCol 用于定位一条记录的字段
	 * @param whichValue 字段的值
	 * @return 可被执行的statement
	 * @throws SQLException 
	 */
	public abstract PreparedStatement createGetItemsStatement(String tableName , String whichCol ,Object whichValue) throws SQLException;
	

	/**
	 * 查询整张表并且排序
	 * @param table 表名
	 * @param whichColSort 要根据那一列排序
	 * @param sortWay 排序方式 升序还是降序 升序传ASCE 降序传DESC
	 * @return 可被执行的statement
	 */
	public PreparedStatement createGetItemsStatement(String tableName,
			String whichCol, Object whichValue, String whichColSort, String sortWay) throws SQLException;
}
