package com.my.dbprocessor;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * 
 * 一个bean对象用于存放一个数据表中的一行数据<br>
 * 如果要想使用BaseTbale<T>类来对数据库进行增删改查操作<br>
 * 所有的T类型的对象都必须由这个类派生出去，才能使得basetable在不知道bean的类内对象的情况下通过反射操作bean对象<br>
 * 
 * 注意：	子类中变量的定义顺序与名称必须与数据库中的字段的名称顺序一一对应<br>
 * 		子类的变量必须为private并且提供按照java命名规范的setter和getter方法<br>
 * 		子类的无参构造函数要显式的调用父类的无参构造函数<br>
 *		 如果不满足上述条件框架将无法正常工作，但仍然有一些应对方法：<br>
 * 如果变量名称与数据表中的名称不一致 <br>
 * 覆写	{@link #getColumnNameByColum(int)}<br>
 * 如果变量顺序与数据表中的顺序不一致<br>
 * 覆写 	{@link #getColumnNameByColum(int)} <br>
 * 		{@link #getFieldByColumn(int)}<br>
 * 		{@link #setFieldByColumn(int, Object)}<br>
 * 具体覆写规则看注释<br>
 * 
 * bean对象中默认将主码设为第一个变量所对应的字段，如果是多个属性决定一条记录或主码不是第一列<br>
 * 请覆写 {@link #getPrimaryKey()}
 * 
 * bean对象提供一套getter和setter方法用于将一个Object数组直接设置给bean对象里的变量或将变量转换成Object数组返回
 * {@link #toObjectArray()} 
 * {@link #setValues(Object...)} 
 * 
 * @author 20136213<br>
 *
 */

public class BaseBean
{
	private Class<? extends BaseBean> bean;
	private Field[] field;

	public BaseBean()
	{
		bean = this.getClass();
		field = bean.getDeclaredFields();
	}
	
	public static BaseBean getEmptyBean()
	{
		return new BaseBean();
	}
	
	/**
	 * 获得这个bean对象中字段的个数，保证返回值与数据表的字段数相等
	 * @return bean对象中字段的个数
	 */
	public int getFieldCount()
	{
		return field.length;
	}
	
	/**
	 * 通过列号来获得bean对象中的一个字段，为了保证序号能与数据表中的项对上号,所以是从1开始的
	 * @param col 序号
	 * @return 一个序号对应的字段
	 */
	public Object getFieldByColumn(int col)
	{
		Object object = null;
		try
		{
			Method method = this.getClass().getMethod("get" + getParameterNameByCol(col));
			object = method.invoke(this);
		} catch (NoSuchMethodException | SecurityException |
				IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e)
		{
			e.printStackTrace();
		}
		return object;
	}
	
	/**
	 * 通过列号来设置对象中变量的值，子类实现时需要进行强制类型转换
	 * @param col 列号
	 * @param value 列号所对应的变量的值
	 */
	public void setFieldByColumn(int col , Object value)
	{
		try
		{
			Method method = this.getClass().getMethod("set" + getParameterNameByCol(col)
					,getTypeByCol(col));
			method.invoke(this,value);
		} catch (NoSuchMethodException | SecurityException |
				IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 通过列号来获取列名 这里默认将变量名当做当做列名，如有不同，请覆写此方法
	 * @param col 列号
	 * @return 列名
	 */
	public String getColumnNameByColum(int col)
	{
		return field[col-1].getName();
	}
	
	/**
	 * 获取主码的列号数组，默认是第一列作为主码，如有不同请覆写
	 * @return 主码的列号
	 */
	public int[] getPrimaryKey()
	{
		return new int[]{1};
	}
	
	/**
	 * @return 主属性的名字
	 */
	public final String[] getPrimaryKeyNames()
	{
		int[] primaryKey = getPrimaryKey();
		String[] keyNames = new String[primaryKey.length];
		for (int i = 0; i < keyNames.length; i++)
			keyNames[i] = getColumnNameByColum(i+1);
		return keyNames;
	}
	
	/**
	 * @return 存放的主属性的值
	 */
	public final Object[] getPrimaryValues()
	{
		int[] primaryKey = getPrimaryKey();
		Object[] values = new Object[primaryKey.length];
		for (int i = 0; i < values.length; i++)
			values[i] = getFieldByColumn(i+1);
		return values;
	}

	
	/**
	 * @return  将一个bean对象转换为一个object数组
	 */
	public Object[] toObjectArray()
	{
		int count = getFieldCount();
		Object[] objects = new Object[count];
		for (int i = 0; i < count; i++)
		{
			objects[i] = getFieldByColumn(i+1);
		}
		return objects;
	}
	
	/**
	 * 通过Object数组给bean对象赋值
	 * @param values object数组
	 */
	public void setValues(Object... values)
	{
		int count = values.length;
		for (int i = 0; i < count; i++)
		{
			setFieldByColumn(i+1, values[i]);
		}
	}
	
	/**
	 * 获取第col个变量的名字并将首字母转为大写
	 * @param col 第几个变量
	 * @return 首字母大写版的变量名
	 */
	private String getParameterNameByCol(int col)
	{
		String name = field[col-1].getName();
		String frist = new String(new char[]{name.charAt(0)});
		name = name.replaceFirst(frist, frist.toUpperCase());
		return name;
	}
	
	/**
	 * 获取第col个变量的数据类型
	 * @param col 第几个变量
	 * @return 数据类型
	 */
	private Class<?> getTypeByCol(int col)
	{
		 return field[col -1].getType();
	}
}
