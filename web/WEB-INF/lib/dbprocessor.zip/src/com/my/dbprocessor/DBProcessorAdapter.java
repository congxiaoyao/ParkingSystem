package com.my.dbprocessor;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * 
 * 公共的数据表操作类
 * 提供一整套面向bean的增删改查操作
 * 
 * 具体操作有 查询所有、通过具体参数查询、排序数据、添加一条记录、
 * 删除一条记录、更改一条记录、查询数据库中的记录总数、将整个数据表转化为二维String数组等
 * 
 * @author 20136213
 *
 * @param <T> 必须继承自BaseBean 详细使用说明看BaseBean类内注释
 * 
 */

public abstract class DBProcessorAdapter<T extends BaseBean>
{
	
	public static final int ORDER_BY_DESC = 0;
	public static final int ORDER_BY_ASCE = 1;
	
	protected DBLinker linker;
	protected StatementCreaterImpl statementCreater;
	protected PreparedStatement statement;
	protected String[] colName;
	
	public DBProcessorAdapter()
	{
		linker = new DBLinker();
		linkToDatabases(linker);
		colName = queryColName();
		statementCreater = new StatementCreaterImpl(linker.getConnection());
	}
	
	/**
	 * 基于统一的bean对象 可以直接为子类提供添加方法
	 * @param bean bean的实现类
	 */
	public void insert(T bean)
	{
		try{
			statement = statementCreater.createInsertStatement
					(getTableName(), bean.toObjectArray());
			statement.executeUpdate();
			statement.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * 删除一条记录 删除与bean中的主属性匹配的记录
	 * @param bean
	 */
	public void delete(T bean)
	{
		String[] keyNames = bean.getPrimaryKeyNames();
		Object[] values = bean.getPrimaryValues();
		try{
			statement = statementCreater.createDeleteStatement
					(getTableName(), keyNames, values);
			statement.executeUpdate();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 通过bean中主属性的值找到一条记录将其他的值修改为bean的值
	 * @param bean
	 */
	public void update(T bean)
	{
		String[] whichColNames = new String[bean.getFieldCount()];
		for (int i = 0; i < whichColNames.length; i++)
			whichColNames[i] = bean.getColumnNameByColum(i+1);
		
		try{
			statement = statementCreater.createUpdateStatement(getTableName(),
					bean.getPrimaryKeyNames(), bean.getPrimaryValues(),
					whichColNames, bean.toObjectArray());
			statement.executeUpdate();
			statement.close();
		} catch (SQLException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * 得到数据表中的所有数据，一行以bean的形式存储，整个表以bean的arraylist存储
	 * @return 整个数据表的arraylist
	 */
	public ArrayList<T> getAllItem()
	{
		ArrayList<T> dataList = null;
		try
		{
			statement = statementCreater.createGetAllItemsStatement(getTableName());
			dataList = analysisResultSet(statement.executeQuery());
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return dataList;
	}
	
	/**
	 * 查找并排序表中所有记录
	 * @param colName 按照那一列的名字排
	 * @param type 升序 ORDER_BY_ASCE 降序 ORDER_BY_DESC
	 * @return 结果集的ArrayList
	 */
	public ArrayList<T> getAllItem(String colName , int type)
	{
		ArrayList<T> dataList = null;
		
		String sortWay = "";
		if(type == ORDER_BY_DESC)
			sortWay = " DESC";
		
		try
		{
			statement = statementCreater.createGetAllItemsStatement(getTableName(), colName, sortWay);
			dataList = analysisResultSet(statement.executeQuery());
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return dataList;
	}
	
	/**
	 * 通过列名查找某一列值为value的记录
	 * @param colName 列名字
	 * @param value 这一列具体的值
	 * @return 结果集的Arraylist形式
	 */
	public ArrayList<T> getItemByParamter(String colName , Object value)
	{
		ArrayList<T> dataList = null;
		try
		{
			statement = statementCreater.createGetItemsStatement(getTableName(), colName, value);
			dataList = analysisResultSet(statement.executeQuery());
		} catch (SQLException e)
		{
			e.printStackTrace();
		}
		return dataList;
	}
	
	/**
	 * 通过列号查找某一列值为value的记录
	 * @param col 列号
	 * @param value 这一列的具体值
	 * @return 结果集的arrayList形式
	 */
	public ArrayList<T> getItemByParamter(int col , Object value)
	{
		return getItemByParamter(getColNameByColIndex(col), value);
	}
	
	/**
	 * 通过列名查找某一列值为value的记录并排序
	 * @param colName 列名
	 * @param value 要查找的值
	 * @param whichColSort 要排序的列
	 * @param sortWay 排序方式 升序 ORDER_BY_ASCE 降序 ORDER_BY_DESC
	 * @return 结果集的arrayList形式
	 */
	public ArrayList<T> getItemByParamter(String colName , Object value , String whichColSort, int sortWay)
	{
		ArrayList<T> dataList = null;
		
		String way = "";
		if(sortWay == 0) way = "DESC";
		
		try {
			statement = statementCreater.createGetItemsStatement(getTableName(), colName, value, 
					whichColSort, way);
			dataList = analysisResultSet(statement.executeQuery());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dataList;
	}
	
	/**
	 * 通过列号查找某一列值为value的记录并排序
	 * @param col 列
	 * @param value 要查找的值
	 * @param whichColSort 要排序的列
	 * @param sortWay 排序方式 升序 ORDER_BY_ASCE 降序 ORDER_BY_DESC
	 * @return 结果集的arrayList形式
	 */
	public ArrayList<T> getItemByParamter(int col , Object value , String whichColSort , int sortWay)
	{
		return getItemByParamter(getColNameByColIndex(col), value, whichColSort, sortWay);
	}
	
	/**
	 * @return 表中总记录的条数
	 */
	public int getItemCount()
	{
		int count = 0;
		try {
			statement = statementCreater.createGetAllItemsStatement(getTableName());
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next())
			{
				count++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return count;
	}
	
	/**
	 * 将一个arraylist转化为二维字符串数组以便生成表格
	 * @param dataList
	 * @return 二维字符串数组
	 */
	public static String[][] arrayListToStringMatrix(ArrayList<? extends BaseBean> dataList)
	{
		int size = dataList.size();
		if(size == 0)
			return null;
		
		BaseBean bean = dataList.get(0);
		String[][] matrix = new String[size][bean.getFieldCount()];
		for (int i = 0; i < size; i++)
		{
			bean = dataList.get(i);
			int count = bean.getFieldCount();
			for (int j = 0; j < count; j++)
			{
				matrix[i][j] = bean.getFieldByColumn(j+1).toString();
			}
		}
		return matrix;
	}
	
	/**
	 * 将一个arraylist转化为二维Object数组以便生成表格
	 * @param dataList
	 * @return 二维Object数组
	 */
	public static Object[][] arrayListToObjectMatrix(ArrayList<? extends BaseBean> dataList)
	{
		int size = dataList.size();
		if(size == 0)
			return null;
		
		BaseBean bean = dataList.get(0);
		Object[][] matrix = new Object[size][bean.getFieldCount()];
		for (int i = 0; i < size; i++)
		{
			bean = dataList.get(i);
			int count = bean.getFieldCount();
			for (int j = 0; j < count; j++)
			{
				matrix[i][j] = bean.getFieldByColumn(j+1);
			}
		}
		return matrix;
	}
	
	/**
	 * 将数据库中的数据以二维数组的形式取出
	 * @return 二维String数组
	 */
	public String[][] getTableToStringMatrix()
	{
		ArrayList<? extends BaseBean> dataList = getAllItem();
		return arrayListToStringMatrix(dataList);
	}
	
	/**
	 * 关闭数据库连接
	 */
	public void closeConnection()
	{
		linker.closeDB();
	}
	
	/**
	 * 将Result解析成arraylist
	 * @param resultSet 查询的结果集
	 * @return 整个数据表的arraylist
	 * @throws SQLException
	 */
	protected ArrayList<T> analysisResultSet(ResultSet resultSet) throws SQLException
	{
		ArrayList<T> dataList = new ArrayList<>();
		while (resultSet.next())
		{
			T bean = getEmptyBean();
			for (int i = 1 ,count = bean.getFieldCount(); i <= count; i++)
			{
				bean.setFieldByColumn(i, resultSet.getObject(i));
			}
			dataList.add(bean);
		}
		return dataList;
	}
	
	/**
	 * 在构造函数中一次性查出来列名的数组保存起来，需要用的时候直接访问数组
	 * @return 列名数组
	 */
	private String[] queryColName()
	{
		ArrayList<String> arrayList = new ArrayList<>();
		try{
			statement = linker.getConnection().
					prepareStatement(linker.createGetColumnsSQL(getTableName()));
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next())
			{
				arrayList.add(resultSet.getString(1));
			}
			statement.close();
		} catch (SQLException e){
			e.printStackTrace();
		}
		return arrayList.toArray(new String[arrayList.size()]);
	}
	
	/**
	 * 通过列号找到列名
	 * @param col
	 * @return
	 */
	public String getColNameByColIndex(int col)
	{
		return colName[col-1];
	}
	
	/**
	 * 此方法需要子类定义数据库的链接方式
	 * @param linker
	 */
	protected abstract void linkToDatabases(DBLinker linker);
	
	/**
	 * BaseTable拿到一个具体的数据表的名字就可以作为父类可以代替子类实现一些基本的功能
	 * @return 数据表的名字
	 */
	protected abstract String getTableName();
	
	/**
	 * 我就没搞明白怎么构造泛型类，估计是构造不了
	 * 于是子类必须要实现这个方法来返回一个Bean对象的子类
	 * @return bean的实现类
	 */
	protected abstract T getEmptyBean();
}


