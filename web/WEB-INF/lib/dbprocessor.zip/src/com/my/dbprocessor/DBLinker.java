package com.my.dbprocessor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBLinker {
	
	public static final int MY_SQL = 0;
	public static final int MS_SQL_SERVER = 1;
	
	private int type = 0;

	private Connection connection;

	/**
	 * 连接到SQL_SERVER数据库
	 * @param dbName
	 * @param server
	 * @param user
	 * @param password
	 */
	public void linkDB_SQL_SERVER(String dbName, String server, String user , String password) {
		setType(1);
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connection=DriverManager.getConnection("jdbc:sqlserver:"+server+
					";databaseName="+dbName+";user="+user+";password="+password);

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 连接到MYSQL数据库
	 * @param dbURL
	 * @param user
	 * @param password
	 */
	public void linkDB_MY_SQL(String dbURL, String user , String password) {
		setType(0);
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection(dbURL,user,password);

		} catch (InstantiationException e)
		{
			e.printStackTrace();
		} catch (IllegalAccessException e)
		{
			e.printStackTrace();
		} catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * 你懂得！！
	 */
	public void linkDB_MY_SQL()
	{
		linkDB_MY_SQL("jdbc:mysql://localhost:3306/restaurantdb",
				"root", "");
	}
	
	public String createGetColumnsSQL(String tableName)
	{
		if(type == 0)
			return "show fields from " +tableName+ ";";
		else if(type == 1)
			return "sp_help "+tableName;
		else {
			return null;
		}
	}

	/**
	 * 关闭数据库连接
	 */
	public void closeDB() {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection()
	{
		return connection;
	}

	public int getType()
	{
		return type;
	}

	public void setType(int type)
	{
		this.type = type;
	}
}