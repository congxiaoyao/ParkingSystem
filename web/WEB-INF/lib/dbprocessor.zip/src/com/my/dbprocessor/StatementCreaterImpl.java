package com.my.dbprocessor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StatementCreaterImpl implements StatementCreater
{

	private Connection connection;
	protected String sql = new String();
	private PreparedStatement statement;

	public StatementCreaterImpl(Connection connection)
	{
		this.connection = connection;
	}

	@Override
	public PreparedStatement createInsertStatement(String tableName,
			Object... values) throws SQLException
	{

		sql = "INSERT INTO " + tableName + " VALUES("
				+ getMultiVarValues(values.length) + ");";
		statement = connection.prepareStatement(sql);
		for (int i = 0; i < values.length; i++)
		{
			statement.setObject(i + 1, values[i]);
		}

		return statement;
	}

	@Override
	public PreparedStatement createDeleteStatement(String tableName,
			String colName, Object value) throws SQLException
	{
		sql = "DELETE FROM " + tableName + " WHERE " + colName + " = ?;";
		statement = connection.prepareStatement(sql);
		statement.setObject(1, value);
		return statement;
	}

	public PreparedStatement createDeleteStatement(String tableName,
			String[] colNames, Object[] values) throws SQLException
	{
		sql = "DELETE FROM " + tableName + " WHERE "
				+ getMultiOptionsWithAND(colNames) + ";";
		statement = connection.prepareStatement(sql);
		for (int i = 0; i < values.length; i++)
		{
			statement.setObject(i + 1, values[i]);

		}
		return statement;
	}

	public PreparedStatement createUpdateStatement(String tableName,
			String[] whichCols, Object[] whichValues, String[] colNames,
			Object[] values) throws SQLException
	{
		sql = "UPDATE " + tableName + " SET "
				+ getMultiOptionsWithComma(colNames) + " WHERE "
				+ getMultiOptionsWithAND(whichCols) + ";";
		statement = connection.prepareStatement(sql);

		int i = 0;
		for (; i < values.length; i++)
		{
			statement.setObject(i + 1, values[i]);
		}
		for (int j = 0; j < whichCols.length; i++, j++)
		{
			statement.setObject(i + 1, whichValues[j]);
		}

		return statement;
	}

	@Override
	public PreparedStatement createUpdateStatement(String tableName,
			String whichCol, Object whichValue, String colName, Object value)
			throws SQLException
	{
		sql = "UPDATE " + tableName + " SET " + colName + "=?" + " WHERE "
				+ whichCol + "=" + "?;";
		statement = connection.prepareStatement(sql);
		statement.setObject(1, value);
		statement.setObject(2, whichValue);
		return statement;
	}

	@Override
	public PreparedStatement createGetAllItemsStatement(String tbaleName)
			throws SQLException
	{
		sql = "SELECT * FROM " + tbaleName + ";";
		statement = connection.prepareStatement(sql);
		return statement;
	}

	@Override
	public PreparedStatement createGetAllItemsStatement(String tbaleName,
			String whichColSort, String sortWay) throws SQLException
	{
		sql = "SELECT * FROM " + tbaleName + " ORDER BY " + whichColSort + " "
				+ sortWay + ";";
		statement = connection.prepareStatement(sql);
		return statement;
	}

	@Override
	public PreparedStatement createGetItemsStatement(String tableName,
			String whichCol, Object whichValue) throws SQLException
	{
		sql = "SELECT * FROM " + tableName + " WHERE " + whichCol + "=?;";
		statement = connection.prepareStatement(sql);
		statement.setObject(1, whichValue);
		return statement;
	}

	@Override
	public PreparedStatement createGetItemsStatement(String tableName,
			String whichCol, Object whichValue, String whichColSort,
			String sortWay) throws SQLException
	{
		sql = "SELECT * FROM " + tableName + " WHERE " + whichCol
				+ "=? ORDER BY " + whichColSort + " " + sortWay + ";";
		statement = connection.prepareStatement(sql);
		statement.setObject(1, whichValue);
		return statement;
	}

	/**
	 * 得到一个"?,?,?"的字符串，问号个数为count
	 * 
	 * @param count
	 * @return
	 */
	private static String getMultiVarValues(int count)
	{
		if (count <= 0)
			return "";

		String wildcard = "?";
		for (int i = 1; i < count; i++)
		{
			wildcard += ",?";
		}
		return wildcard;
	}

	/**
	 * 得到一个"列名1=？ AND 列名2=？"的字符串，Option的个数为colName.lenth
	 * 
	 * @param colName
	 * @return
	 */
	private static String getMultiOptionsWithAND(String[] colName)
	{
		if (colName.length <= 0)
			return "";
		String options = colName[0] + "=?";
		for (int i = 1; i < colName.length; i++)
		{
			options = options + " AND " + colName[i] + "=?";
		}
		return options;
	}

	/**
	 * 得到一个"列名1=？, 列名2=？"的字符串，Option的个数为colName.lenth
	 * 
	 * @param colName
	 * @return
	 */
	private static String getMultiOptionsWithComma(String[] colName)
	{
		if (colName.length <= 0)
			return "";
		String options = colName[0] + "=?";
		for (int i = 1; i < colName.length; i++)
		{
			options = options + " , " + colName[i] + "=?";
		}
		return options;
	}
}
